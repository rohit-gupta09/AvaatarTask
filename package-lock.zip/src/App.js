import './App.css';
// import Corousal from './components/Corousal/Corousal';
// import Nav from './components/Nav';
import Navbar from './components/Navbar';

function App() {
  return (
    <div className="App1">
    <Navbar></Navbar>
    </div>
  );
}

export default App;
